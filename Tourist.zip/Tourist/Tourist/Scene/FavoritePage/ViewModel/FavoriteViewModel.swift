//
//  FavoriteViewModel.swift
//  Tourist
//
//  Created by Mehmet Ali Kılıçlı on 4.07.2023.
//

import UIKit
import CoreData

protocol FavoriteViewModelDelegate: AnyObject {
    
}

protocol FavoriteViewModelProtocol {
    func deleteFavorite(placeId : String)
    func numberOfItem()
}

class FavoriteViewModel {
    
    weak var delegate : FavoriteViewModelDelegate?
    
    
    
    
    
    
    
}
