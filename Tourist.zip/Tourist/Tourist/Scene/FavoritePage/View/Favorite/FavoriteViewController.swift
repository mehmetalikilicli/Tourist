//
//  FavoriteViewController.swift
//  Tourist
//
//  Created by Mehmet Ali Kılıçlı on 3.07.2023.
//

import UIKit
import CoreData

class FavoriteViewController: UIViewController {
    
    
    @IBOutlet weak var favoriteTableView: UITableView!

    var favoritePlacesIdList = [String]()
    var favoritePlacesList = [DetailFeature]()
    
    //private var viewModel : FavoriteViewModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configuration()
        //getFavorites()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        //viewModel.delegate = self
        getFavorites()

        //NotificationCenter.default.addObserver(self, selector: #selector(getFavorites), name: NSNotification.Name("newFavorite"), object: nil)
    }
    
    @objc func getFavorites(){
        
        favoritePlacesIdList.removeAll(keepingCapacity: false)
        favoritePlacesList.removeAll(keepingCapacity: false)

        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Favorite")
        request.returnsObjectsAsFaults = false
        do {
            let results = try context.fetch(request)
            
            if results.count > 0 {
                
                for result in results as! [NSManagedObject] {
                    if let placeId = result.value(forKey: "placeId") as? String {
                        PlaceDetailService.shared.getPlaceDetail(placeId: (placeId)) { detailFeature in
                            if let detailFeature = detailFeature {
                                self.favoritePlacesList.append(detailFeature)
                            } else {
                                self.makeAlert(title: "Hata", message: "Favori Yerleriniz Getirilemedi!")
                            }
                            DispatchQueue.main.async {
                                self.favoriteTableView.reloadData()
                            }
                        }
                        self.favoritePlacesIdList.append(placeId)
                        
                    }
                }
            }
        } catch {
            print("error")
        }
    }
    
    func configuration(){
        favoriteTableView.dataSource = self
        favoriteTableView.delegate = self
        
        favoriteTableView.register(UINib(nibName: "FavoriteTableViewCell", bundle: nil), forCellReuseIdentifier: "favoriteCell")
        
    }
    
    func makeAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        let okButton = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil)
        alert.addAction(okButton)
        self.present(alert, animated: true, completion: nil)
    }
}

extension FavoriteViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return favoritePlacesList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "favoriteCell") as! FavoriteTableViewCell
        cell.textLabel?.text = favoritePlacesList[indexPath.row].properties?.name
        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        if editingStyle == .delete {
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            let context = appDelegate.persistentContainer.viewContext
            
            let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Favorite")
            
            let placeId = favoritePlacesIdList[indexPath.row]
            
            fetchRequest.predicate = NSPredicate(format: "placeId = %@", placeId)
            
            fetchRequest.returnsObjectsAsFaults = false
            
            do {
                let results = try context.fetch(fetchRequest)
                
                if results.count > 0 {
                    
                    for result in results as! [NSManagedObject]{
                        if let placeId = result.value(forKey: "placeId") as? String {
                            
                            if placeId == favoritePlacesIdList[indexPath.row] {
                                
                                context.delete(result)
                                favoritePlacesIdList.remove(at: indexPath.row)
                                favoritePlacesList.remove(at: indexPath.row)
                                self.favoriteTableView.reloadData()
                                
                                do{
                                    try context.save()
                                } catch {
                                    print("Error")
                                }
                                break
                            }
                            
                        }
                    }
                    
                }
            }
            catch {
                print("Error")
            }
            
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        PlaceDetailService.shared.getPlaceDetail(placeId: self.favoritePlacesIdList[indexPath.row]) { detailFeature in
            DispatchQueue.main.async {
                let placeDetailVC = PlaceDetailViewController()
                placeDetailVC.placeDetail = detailFeature
                self.navigationController?.pushViewController(placeDetailVC, animated: true)
            }
        }
    }
}
