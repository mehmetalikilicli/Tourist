//
//  PlaceDetailViewController.swift
//  Tourist
//
//  Created by Mehmet Ali Kılıçlı on 18.06.2023.
//

import UIKit
import MapKit
import CoreData

class PlaceDetailViewController: UIViewController {
    
    var placeDetail: DetailFeature?
    
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var adressLine1Label: UILabel!
    @IBOutlet weak var adressLine2Label: UILabel!
    @IBOutlet weak var phoneNumberLabel: UILabel!
    @IBOutlet weak var stateLabel: UILabel!
    @IBOutlet weak var cityLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setUpUI()
    }
    
    
    @IBAction func addFavorite(_ sender: Any) {
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        
        let newFavorite = NSEntityDescription.insertNewObject(forEntityName: "Favorite", into: context)
        
        newFavorite.setValue(placeDetail?.properties?.place_id, forKey: "placeId")

        
        do {
            try context.save()
            print("Success")
        } catch {
            print("error")
        }
        
        //For reflesh favorite list instantly(Listening)
        //NotificationCenter.default.post(name: NSNotification.Name("newFavorite"), object: nil)
        
        makeAlert(title: "Favoriye Eklendi", message: "\(placeDetail?.properties?.name ?? "Bu yer") başarılı bir şekilde favorilere eklendi.")
    }
    
    @IBAction func share(_ sender: Any) {
        makeAlert(title: "Paylaşıldı", message: "\(placeDetail?.properties?.name! ?? "Bu Yer") paylaşıldı.")
    }
    func setUpUI(){
        
        if let placeDetail = placeDetail {
            nameLabel.text = placeDetail.properties?.name ?? "Unknown Name"
            adressLine1Label.text = placeDetail.properties?.address_line1 ?? "Adress Line 1"
            adressLine2Label.text = placeDetail.properties?.address_line2 ?? "Adress Line 2"
            phoneNumberLabel.text = placeDetail.properties?.contact?.phone ?? "Unknown Phone Number"
            stateLabel.text = placeDetail.properties?.state ?? "Unknown State"
            cityLabel.text = placeDetail.properties?.city ?? "Unknown City"
        }
    }
    
    
    @IBAction func showOnMapButton(_ sender: Any) {
        
        if placeDetail != nil{
            let placeShowOnMapVC = ShowPlaceOnMapViewController()
            placeShowOnMapVC.place = placeDetail
            self.navigationController?.pushViewController(placeShowOnMapVC, animated: true)
        } else {
            makeAlert(title: "Hata", message: "Bu yerin konumuna ulaşılamıyor!")
        }
    }
    
    func makeAlert(title: String, message: String) {
            let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
            let okButton = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil)
            alert.addAction(okButton)
            self.present(alert, animated: true, completion: nil)
        }
}
