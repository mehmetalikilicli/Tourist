//
//  PlacesCategoryViewModel.swift
//  Tourist
//
//  Created by Mehmet Ali Kılıçlı on 8.07.2023.
//

import Foundation

protocol PlaceCategoryViewModelDelegate: AnyObject {
    func placeCategoriesFetched()
    func didSelectPlaceCategory(_ places: [Feature])
}


class PlaceCategoryViewModel {
    var placeCategoriesList = [PlaceCategory]()
    weak var delegate: PlaceCategoryViewModelDelegate?
    
    func fetchPlaceCategories() {
        placeCategoriesList = PlaceCategoryService.shared.getPlaceCategories()
        delegate?.placeCategoriesFetched()
    }
    
    func placeCategoriesCount() -> Int {
        return placeCategoriesList.count
    }
    
    func placeCategory(at index: Int) -> PlaceCategory {
        return placeCategoriesList[index]
    }
    
    func selectPlaceCategory(at index: Int) {
        let placeCategory = placeCategoriesList[index]
        PlaceService.shared.getPlaces(placeName: placeCategory.name ?? "") { [weak self] placeList in
            DispatchQueue.main.async {
                guard let placesList = placeList else {
                    // Yerler çekilemedi, hata durumuyla başa çıkılabilir
                    return
                }
                
                self?.delegate?.didSelectPlaceCategory(placesList)
            }
        }
    }
}
