//
//  PlacesCategoryViewConroller.swift
//  Tourist
//
//  Created by Mehmet Ali Kılıçlı on 8.07.2023.
//

import UIKit

class PlacesCategoryViewController: UIViewController {
    @IBOutlet weak var placeCategoryTableView: UITableView!
    
    var viewModel: PlaceCategoryViewModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureTableView()
        setupViewModel()
        viewModel.fetchPlaceCategories()
    }
    
    private func configureTableView() {
        placeCategoryTableView.delegate = self
        placeCategoryTableView.dataSource = self
        placeCategoryTableView.register(UINib(nibName: "PlaceCategoryTableViewCell", bundle: nil), forCellReuseIdentifier: "placeCategoryCell")
    }
    
    private func setupViewModel() {
        viewModel = PlaceCategoryViewModel()
        viewModel.delegate = self
    }
}

extension PlacesCategoryViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.placeCategoriesCount()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "placeCategoryCell", for: indexPath) as! PlaceCategoryTableViewCell
        let placeCategory = viewModel.placeCategory(at: indexPath.row)
        cell.placeCategoryName.text = placeCategory.name
        cell.placeCategoryImage.image = UIImage(named: placeCategory.image ?? "")
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        viewModel.selectPlaceCategory(at: indexPath.row)
    }
}

extension PlacesCategoryViewController: PlaceCategoryViewModelDelegate {
    func placeCategoriesFetched() {
        DispatchQueue.main.async {
            self.placeCategoryTableView.reloadData()
        }
    }
    
    func didSelectPlaceCategory(_ places: [Feature]) {
        DispatchQueue.main.async {
            let placesViewModel = PlacesViewModel(places: places)
            let placesVC = PlacesViewController()
            placesVC.viewModel = placesViewModel
            self.navigationController?.pushViewController(placesVC, animated: true)
        }
    }
}
