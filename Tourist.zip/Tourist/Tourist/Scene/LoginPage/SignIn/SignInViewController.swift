//
//  SignInViewController.swift
//  Tourist
//
//  Created by Mehmet Ali Kılıçlı on 2.07.2023.
//

import UIKit

class SignInViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    
    @IBAction func button(_ sender: Any) {
        
        let mainTabbar = PlaceDetailViewController()
        self.navigationController?.pushViewController(mainTabbar, animated: true)
    
    }
}
