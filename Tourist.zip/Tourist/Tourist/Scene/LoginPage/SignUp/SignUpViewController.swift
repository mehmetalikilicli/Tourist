//
//  SignUpViewController.swift
//  Tourist
//
//  Created by Mehmet Ali Kılıçlı on 2.07.2023.
//

import UIKit

class SignUpViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
        
    }
}
