//
//  FavoritePlace.swift
//  Tourist
//
//  Created by Mehmet Ali Kılıçlı on 4.07.2023.
//

import Foundation

// MARK: - PlaceDetail
struct FavoritePlace: Codable {
    let type: String?
    let features: [FavoriteFeature]?
}

// MARK: - Feature
struct FavoriteFeature: Codable {
    let type: String?
    let properties: FavoriteProperties?
}

// MARK: - Properties
struct FavoriteProperties: Codable {
    let name: String?
    let contact: FavoriteContact?
    let city, state: String?
    let address_line1, address_line2: String?
    let lat, lon: Double?
    let place_id: String?
}

// MARK: - Contact
struct FavoriteContact: Codable {
    let phone: String?
}


