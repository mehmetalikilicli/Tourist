//
//  PlaceCategoryModel.swift
//  Tourist
//
//  Created by Mehmet Ali Kılıçlı on 14.06.2023.
//

import Foundation


struct PlaceCategory {
    var name: String?
    var image: String?
}
